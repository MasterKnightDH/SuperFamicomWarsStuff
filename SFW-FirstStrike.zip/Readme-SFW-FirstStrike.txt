Super Famicom Wars First Strike Patch
By Master Knight DH

----------------------------------------------------------------------------------------------------

Files

NOTE: Checksum isn't corrected. Please be sure to do that manually if needed.

Either of these would be implemented into the non-header version of Super Famicom Wars, using 
LunarIPS to do so. Please choose whichever one is desired. Both of these are known to work with 
the Nintendo Power version of the game, and should prove to work with optiroc's translation patch.

*SFWars-FirstStrike.ips - adds first striking into the game
*SFWars-FirstStrike-NoDefLuck.ips - the same, but also eliminates the defender's luck damage

----------------------------------------------------------------------------------------------------

Introduction

Super Famicom Wars is the successor to the original Famicom Wars, and the predecessor to the 
Advance Wars series. It's an important title in the Nintendo Wars series because a lot of the 
design in the Advance Wars games trace back to Super Famicom Wars. Nonetheless, SFW does suffer 
from having some dated gameplay.

One such problem is simultaneous strike. This mechanic difference of both units attacking at the 
same time results in direct unit usage being a messy affair of overreliance on matchup advantage 
reliance.

----------------------------------------------------------------------------------------------------

First Strike Patch's purpose

A user named schil227 made a patch for Famicom Wars to get rid of simultaneous strike, and he 
readily provides his 2 cents about the issue. His input can be found here:
https://github.com/schil227/FamicomWarsFirstStrike

Super Famicom Wars has its own other dated design issues that got rightfully phased out in 
Advance Wars, and I can even think of two that aren't even a plague in Game Boy Wars 3, both 
involving transports. However, simultaneous attacking is an obvious problem regardless and is 
worth zapping off for improved gameplay. With Game Boy Wars 3, my PALBal patch's direction with 
attack order was expanding upon the Focus system, but Super Famicom Wars would inevitably play 
to something more simplistic. Ironically, SFW not having built-in first attack in any form would 
come to complicate matters, as I'll get to.

The main idea is to reduce punishment just for using direct fire at all, and instead add meaning 
to maneuvers. Cruiser VS Sub is particularly egrigious in base game as a result of the Cruiser 
taking 35% from the Sub in counterattack because of simultaneous strike. First Strike newly makes 
the counter damage more like 3% (4% with Yamamoto's free Levels), so that the Cruiser can smite 
another Sub before potentially going back for repairs. There are other examples of First Strike 
being beneficial, such as the Attacker having less disjointed design that makes it more powerful 
than welcome on enemy phase (to be sure, there's still blatant issues, even if at least the 
Fighter would newly go 9-2 against the Attacker when initiating), though I can trust that you the 
reader would have the general idea down.

I'm additionally including a variation that removes the defender's luck damage. Why am I doing 
such? Quite simply, it's inane to see armored tanks get damaged by Infantry's small arms 
fire, and it doesn't even help when luck damage doesn't even get diminished by HP loss, which 
actually also applies to terrain cover. Advance Wars fixes both, but I did get the chance to 
make a touch that reduces enemy phase friendliness further than what First Strike manages.

----------------------------------------------------------------------------------------------------

Technical challenges

The whole effort wasn't easy, primarily beacause unlike Game Boy Wars 3, Super Famicom Wars does 
not have a pre-built first strike scenario where simply giving the attacker extra Focus would be 
massive headway in any desired venture, because the Focus mechanic isn't even a thing in SFW. This 
meant having to look through the relevant coding. 

Though the base ROM would provide over 2000 bytes of free space in the same ROM bank as what is 
relevant, the translation patch uses most of that, leaving me with 153 bytes of free space. While 
I am personally not a fan of the translation patch's art direction, it's the only resource that is
around for allowing SFW to be played in English, so I had to be particularly watchful, though 
they do say that necessity is the mother of invention, and I kind of think that applies here.

What got annoying fast was that HP's role in damage isn't even done in the final subroutine, yet 
the order of operations was calculating both units' damage before establishment of both units' 
new HP, notably with the attacker's new HP being established first, further confounding things. 
Already, the order of operations had to be updated, but there were even further complications.

For whatever reason, the subroutine that handles HP's role for the unit's damage infliction also 
includes at the end to establish the unit's terrain protection, and I can't even joke that whoever 
at Intelligent Systems went with that was a clown because first strike wasn't even in Famicom Wars 
or Game Boy Wars 1/2/Turbo. While it looks like the terrain cover establishment is done earlier, 
I didn't want to risk this portion proving to not be superfluous. For that, I had to rewrite the 
procedures involved to split them apart.

This isn't even getting into how the general damage calculations is called by THREE subroutines. 
Accounting for all of them was something I had to do to avoid some ugly complication.

Thankfully, since there was similar enough ASM, I was able to go ahead and compact the needed 
instructions and eliminate the usage of old procedures, allowing for using their bytes as extra 
space. (In hindsight, that might have been ideal to do consistently, given the space I was using 
on the new procedure as a whole.) It took a while to come up with the coding, but I needed only 
2 test runs, the failure from the first one being the result of a coding instruction typo.

At least now, this is raring to go.

----------------------------------------------------------------------------------------------------

Contact:
*Discord: MasterKnightDH
*YouTube: https://www.youtube.com/@MasterKnightDH

----------------------------------------------------------------------------------------------------

Credits

-schil227 for his inspiration with his First Strike patch for Famicom Wars
-The owner of Game Boy Wars Network for information provided here:
http://gbwn.main.jp/
-MarioMastar for being a long time friend in general
-Intelligent Systems for making Super Famicom Wars, of course
-The Advance Wars communities for providing general support, instead of claiming to have been 
trying to get rid of the troll for years despite evidence to the contrary and also not even 
bothering to link to Mangs' actions when calling him out while drowning out my efforts to call out 
the cobra effect by subjecting me to some cheap slander campaign and shutting out things like 
Nyvelion's unfairly deleted post about abuse by a Yandere
-Vanilla TV Tropes and Tropers' Hub for being all nice and pleasant non-snobbish people who don't 
ban people for grammar errors and prove generally exclusionary and unwilling to engage in 
respectable discussion while claiming to be democratic