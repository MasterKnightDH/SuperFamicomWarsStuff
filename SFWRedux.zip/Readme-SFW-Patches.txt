Super Famicom Wars Redux
By Master Knight DH

----------------------------------------------------------------------------------------------------

Files

NOTE: Checksum isn't corrected. Please be sure to do that manually if needed.

All of these patches can be applied to a non-headered Super Famicom Wars ROM via usage of 
LunarIPS, which was used to create the patches. These should prove to work in combination with 
optiroc's translation patch due to the spare space that was used not being used by that. The 
Master Patch can be used to apply basically all of the patches at once.

LunarIPS can be used to apply the patches to a non-headered Super Famicom Wars ROM. Please apply 
the patches of choice to it as desired. In general, order has shouldn't matter. And naturally, 
a copy of the base ROM should be used rather than the base ROM itself in case something goes awry.

*SFWars-MasterPatch.ips - combines all of the below (except DamageCalcClassic, HarborExtraGold, 
and FirstStrike due to those being expanded upon)
*SFWars-FirstStrike.ips - adds first striking into the game
*SFWars-FirstStrike-NoDefLuck.ips - the same, but also eliminates the defender's luck damage
*SFWars-TransportFix.ips - has transports not lose their turn to a unit being loaded, and their 
cargo not take damage as they do
*SFWars-RepairTopOff.ips - sub-HP rounds up in terms of Display HP when repairs are done
*SFWars-DamageCalcClassic.ips - changes damage calculations to be based on the AW series damage 
calculations
*SFWars-DamageCalcKinetic.ips - expansion of the above that encourages player phase involvement 
and reduces the power of higher range attacks
*SFWars-DeployAway.ips - allows for deployment at any Factory, Harbor, or Train Station without 
any more need for proximity to the HQ
*SFWars-HarborExtraGold.ips - Harbors each provide 2000G instead of 1000G for income
*SFWars-TradePointsExtraGold.ips - Harbors and Train Stations each provide 2000G instead of 1000G 
for income
*SFWars-XPChanges.ips - expands the EXP system to reward kills, survival, and participation, and 
additionally improve EXP rates in general
*SFWars-MovementFix.ips - Movement Costs Patch, improving Movement Costs to be less excessive
*SFWars-Rebalance.ips - changes to damage table values, as well as Ammo, Movement Power, and price 
amounts, as an effort to improve player experience (no Vision changes for improving Fog of War, 
sorry about that)

----------------------------------------------------------------------------------------------------

Introduction

Super Famicom Wars is the successor to the original Famicom Wars, and the predecessor to the 
Advance Wars series. It's an important title in the Nintendo Wars series because a lot of the 
design in the Advance Wars games trace back to Super Famicom Wars. Nonetheless, SFW does suffer 
from having some dated gameplay.

These patches are designed to improve upon the player experience. There's changes that are 
inspired by how the Advance Wars series changes things up, though some changes are also done to 
show how the actual Advance Wars series can be improved while maintaining involvement of player 
intuition. The Master Patch allows for implementing all of the changes at once, but which changes 
the player wants is put in separate patches, and it shouldn't be too hard for them to do a bit of 
customization with rebalancing via Hex Workshop as needed.

Please note that this is not an exhaustive list of improvements or ideas that I would have for 
Super Famicom Wars. My motivation for providing improvement is actually limited, though I am open 
to providing support to further effort to improve things, providing of course that the person 
offering to chime in can be trusted in the midst of the mess with how the Advance Wars communities 
endorse an unrepentant girl pleasures assailant and are willing to lie in cruel manners to disrupt 
efforts to call out as much. There are people I know I can trust, though they are few and far 
between and likely worried about ineffectiveness with their own gestures. I'd be a bit more 
motivated about handling things with Game Boy Wars 3, though I'm not expecting people will be too 
interested in that.

----------------------------------------------------------------------------------------------------

First Strike Patch's purpose

(Copy-and-pasted from the stand-alone release's own Readme.)

A user named schil227 made a patch for Famicom Wars to get rid of simultaneous strike, and he 
readily provides his 2 cents about the issue. His input can be found here:
https://github.com/schil227/FamicomWarsFirstStrike

Super Famicom Wars has its own other dated design issues that got rightfully phased out in 
Advance Wars, and I can even think of two that aren't even a plague in Game Boy Wars 3, both 
involving transports. However, simultaneous attacking is an obvious problem regardless and is 
worth zapping off for improved gameplay. With Game Boy Wars 3, my PALBal patch's direction with 
attack order was expanding upon the Focus system, but Super Famicom Wars would inevitably play 
to something more simplistic. Ironically, SFW not having built-in first attack in any form would 
come to complicate matters, as I'll get to.

The main idea is to reduce punishment just for using direct fire at all, and instead add meaning 
to maneuvers. Cruiser VS Sub is particularly egrigious in base game as a result of the Cruiser 
taking 35% from the Sub in counterattack because of simultaneous strike. First Strike newly makes 
the counter damage more like 3% (4% with Yamamoto's free Levels), so that the Cruiser can smite 
another Sub before potentially going back for repairs. There are other examples of First Strike 
being beneficial, such as the Attacker having less disjointed design that makes it more powerful 
than welcome on enemy phase (to be sure, there's still blatant issues, even if at least the 
Fighter would newly go 9-2 against the Attacker when initiating), though I can trust that you the 
reader would have the general idea down.

I'm additionally including a variation that removes the defender's luck damage. Why am I doing 
such? Quite simply, it's inane to see armored tanks get damaged by Infantry's small arms 
fire, and it doesn't even help when luck damage doesn't even get diminished by HP loss, which 
actually also applies to terrain cover. Advance Wars fixes both, but I did get the chance to 
make a touch that reduces enemy phase friendliness further than what First Strike manages.

----------------------------------------------------------------------------------------------------

Transport Fix Patch

There are two gameplay mechanic differences in Super Famicom Wars with transports compared to 
the Advance Wars titles:
-Loading a transport ends its turn immediately
-If a transport is involved in combat, any loaded units have their HP hard-capped to the 
transport's new HP value

It's worth pointing out that while these are in Famicom Wars and Game Boy Wars 1/2/Turbo, 
Game Boy Wars 3 saw fit to not involve these particular mechanics. Rightly so, because despite 
the excuse of realism, these mechanics just damage usability of transports, although transport 
viability would likely still be sketchy even with this patch.

The forced turn ending on loading is the bigger problem, slowing down transport usage by way too 
much, which particularly compromises the Lander. As such, fixing it was naturally going to be an 
epic journey of modifying quite a bit of ASM to make sure that-

01caf5 ad d5 0f      LDA   !$0xfd5
01caf8 09 80         ORA   #$0x80              Force sets transport's Turn Ended flag
01cafa 8d d5 0f      STA   !$0xfd5
01cafd 22 0a ab 81   JSL   !>$DAT_81ab0a

.......oh. I think I'm now understanding how Léo Lam must have felt when he fixed Deku Hopping 
in Majora's Mask 3D modding. Okay then!

Incidentally, I could also change $01CE7C to $00 to have dropped units have their turn available, 
but I don't want to do such a change here. Besides, that's part of a LDA Immediate instruction, 
so it would just be unconditional and allow things like Bazookas effectively having 5 Movement 
Power plus whatever the transport has. I'd be wanting to do something more extensive with the ASM 
in a more active balance patch than this.

Having the loaded units' HP change only happen if the transport is destroyed to ALSO destroy the 
loaded units would have been a simplistic change, but I opted to get creative to keep the general 
subroutine from being run (averting the loops) if the transport has any HP left. The end result 
also saves 4 bytes on the ROM, although that's ultimately not much. Even then, it was inevitably 
silly to see an APC get poked and suddenly the inside Infantry loses more than half their HP 
beacause the APC was already at 3 HP before. Yuck.

Oh, and yeah, in base game, loading the unit already doesn't set off the HP hard capping. Only 
combat does. Even with that in mind, the unit inside was more likely to have value than the 
transport itself.

----------------------------------------------------------------------------------------------------

Repair Sub-HP Top-Off Patch

This is really a quality of life provision that has been in the Advance Wars series, including the 
very first Advance Wars. In Super Famicom Wars, the Sub-HP top-off only applies if the repaired 
unit isn't in need of 2 Display HP of repairs. This patch makes it so that the Sub-HP is newly 
increased to the next multiple of 10 if it already isn't such. It's not a major buff, but it can 
help with the momentum maintenance with direct fire units. (As a minor note, this benefit only 
applies if payment for at least 1 Display HP can be applied.)

A new subroutine is added: being able to set the Accumulator to 10 times the Display HP. Setting 
the Accumulator to Display HP itself is already a preexisting subroutine necessitated by things 
like HP display, Capture rates, etc. This is used to make sure the 10x Display HP value is used 
instead of the current Sub HP value when doing repairs. And it would come to be useful in other 
things as well.

----------------------------------------------------------------------------------------------------

Classic Damage Calculation Patch

The name is somewhat of a misnomer because Super Famicom Wars came out before Advance Wars, yet 
people would be familiar with SFW from AW anyway. There are a few changes done with this patch to 
better involve Advance Wars 1's damage calculations compared to in SFW base:
-Luck Damage is newly influenced by HP
-HP influence on damage now uses Display HP x 10 / 100, or effectively Display HP / 10
-HP influence actually works on Terrain Cover

By the way, Luck Damage unfortunately doesn't get reduced by the defense boosts from Level Ups.
That would require extensive ASM overhauling, and what I want to do is already worrying enough. 
Still, since I even provide an extension to the First Strike patch that disables the defender's 
Luck Damage, this might be a good thing.

As an added bonus, I added a linear interpolation subroutine for that last one, clocking in at 128 
bytes including an admittedly redundant Set Carry Flag instruction. Granted, since the first value 
of the linear interpolation is always going to be 0 for terrain cover, this might seem like a 
pointless idea. However, this does go into something a little more ambitious.

----------------------------------------------------------------------------------------------------

Kinetic Damage Calculation Patch

This patch includes the Classic Damage Calculation Patch's changes, but also introduces some 
concepts that would improve player phase emphasis and softens high range fire. As follows:
-During direct fire attacking, for the purposes of defense boosts, the defender's Display HP is 
reduced by 2
-The defender's attack boost from Level Ups is halved
-The defender's defense boost from Level Ups is newly influenced by their HP
-3+ range attacks have their attack boost from Level Ups fractioned
-4+ range attacks get a 10% attack penalty per tile past the 3rd one

This is primarily to boost point counters and also stop excessive backlash with mirror matchups. 
I can especially bring up how the involved concepts, put under Days of Ruin calculations, would 
newly let 2 Light Tanks point-counter a Tabitank, instead of a result of the Tabitank just 
rampaging on any defense that doesn't involve Airport favoritism in the map.

For starters, the defender's terrain cover being less effective means that they'll take some 
extra damage. The influence of this being additive allows for minimizing influence at higher HP 
values while still disrupting enemy phase invincibility. This is also only applying during direct 
fire attacks; indirects will still deal with the same Cover amounts, which the anti-surface range 
attacks will still put up with, while anti-air range attacks won't even care.

HP influence applying to the defense boosts from Level Ups also involves what in hindsight would 
have been worth applying to CO defense boosts in the Advance Wars games: allowing for chipping at 
high DEF COs' units better. Suddenly, Boss COs like Sturm and Caulder would more highlight the 
vitality of mechanics like these, instead of being powerful for its own sake. AWDS Kanbei would 
also have been significantly more fair, if still very monstrous. And here? Well, the Level Ups 
only provide Defense boosts on the 3rd and 4th Level Ups, but those provide enough to be worth 
addressing. And of course, the effectively lower Display HP for the defender's defense boosts 
would also further disrupt enemy phase invincibility.

Next is the attack boost from Level Ups being halved for the defender. This already has a purpose 
of making Yamamoto into a CO who can be fought with better fluidity, when the Fighter mirror would 
stop turning maps like Ball Islands into attrition fest nightmares. You can guess that this would 
actually have been nice for staggering the likes of AW1 Max and AW2 Kanbei, even if the latter 
would still have had his stupid high stats persist into enemy phase. This still prevents overly 
effective attack stats from counterattacks. (By the way, conveniently, Sonja doesn't even provde 
attack boosts, discounting the 10% ATK boost for CO Power usage in AW1 and AWDS. Guess what this 
means?)

And finally, something I came up later into working on these patches, is reduced firepower for 
range attacks. There's now an attack penalty of 10% per space of distance from the target past the 
first 3 spaces, in addition to attack boosts being subject to linear interpolation fractioning off 
1/10 of the attack boost per space of distance past the first 2 spaces. This is to prevent 
excessive power for 5 range attacks, while leaving 2 Range attacks alone. And for those wondering, 
if this were to be added into the AW games, it would be advised to give Grit a unique attribute to 
ignore 1 space of the penalty (2 with Snipe Attack and 3 with Super Snipe) and also take half the 
penalty to begin with. At any rate, we don't need range units creating campfest maps. They still 
can potentially do that here, but at least Bean Island should no longer be a horror show 
introduction to newbies.

As a note, having looked into how Bounty River plays out, I recognize that Battleships at high 
Levels can feel unsatisfying about damage output against infantry because of the attack loss. 
Even then, I'm more open to upping a few damage values than I am to removing the concepts that 
I'm introducing with this patch. My concern is still how terrain can amplify the toxicity of range 
units. I'm more generous than I would be toward range attacks in Kid Icarus Uprising with how much 
those benefit from insane attack boosts.

----------------------------------------------------------------------------------------------------

Deployment Away From HQ Patch

Does what it says on the tin. This allows for deploying from ANY controlled Factory, Harbor, or 
Train Station regardless of whether or not it's within the 5x5 square area centering around the 
player's controlled HQ.

You might notice that Airports are not included there. That's actually deliberate. Anybody who 
wants to change that actually would require going through the same epic quest that Léo Lam went 
through to fix Deku hopping in Majora's Mask 3D. For those who can manage, it's still worth 
remembering that I'm being wary of maps deteriorating into air unit bias if Airports are readily 
available. This patch doesn't do much otherwise without a map editor, other than the obvious fix 
of botes being deployed at locations likely to be closer to the action.

----------------------------------------------------------------------------------------------------

Harbors/Trade Points Extra Gold Patches

A bit of tweaking to the income provision and Harbors now provide doubled Gold. Very useful in 
the midst of arrogant politician leaders who think being a reflection of the general Eagleland 
Type Two idiocy is a bright idea. Oh, and it also makes it easier to build units on maps with 
navy, but I'm sure that's less important, because certain guys who mock lust-induced murder 
victims say so.

And yes, like with Harbors in the Game Boy Wars 3 PALBal patch providing both Gold and Materials, 
this is based off of Harbors in Famicom Wars and Game Boy Wars 1/2/Turbo providing extra Gold. 
There is nothing "woke" about having a property that doesn't resupply/repair land or air units 
provide some more funding that land and air units can still work with. Obviously, this doesn't 
quite fix the navy itself any more than California is immune to the brand of hubris displayed by 
characters like Light Yagami or the Jedi Order, yet this would still help kickstart the ability 
to build a navy, even ever so slightly.

Trade Points Extra Gold does the same as Harbor Extra Gold, except also having Train Stations 
provide the income increase to 2K. This is in line with the sensibility of having trade point 
locations providing economy, and Train Stations ALSO don't heal land units other than the Train 
Gun. While this likely would do only so much, it would at least improve the aesthetic.

----------------------------------------------------------------------------------------------------

Experience Changes Patch

The following changes are done in the ASM:
-Base EXP (that is, the EXP before the Partner Unit Type multiplier) for each side during direct 
fire is increased by 25 plus a quarter of the partner's original HP
-Range attacks has the defender at 125 Base EXP, not subtracting the attacker's HP value at all
-A Kill Bonus is provided as 100 Base EXP

I was having trouble figuring out a good formula for direct fire EXP, but I realized that 
magnifying the influence of the partner's original HP works out in slight encouragement of attacks 
against healthy units, as a bit of risk assessment. This also provides threat to thoughtless 
attacking with high bounty units. Looking at you, Attacker.

Defensive EXP against range attacks worked out in Game Boy Wars 3 PALBal Patch. It would almost 
assuredly stagger thoughtless attacks by the indirects here as well. The Rocket Launcher's 
deservedly high bounty would especially result in the other unit getting 1 Level Up per shot for 
the first 2 shots. Mix in a lack of participation bonus for the attacking unit itself and now 
the player would surely want to put consideration in their range attacks.

Kill Bonus is self explanatory. It's NOT reduced for range fire because finishing off a unit can
easily be suboptimal compared to weakening a still active threat.

All of the PUT multipliers have been increased by 1, with the following exceptions:
-Bazooka Soldier, by +2 (result of 3) - this is due to balance changes in other patches to make 
Bazooka Soldiers better at their job
-Recon, by +2 (result of 3) - Recons are notorious FTA pests, so the punishment against them 
should actually exist to catch their bad usage
-Anti-Air Artillery, remaining at 2 - has some SERIOUS usability problems, and should NOT be 
EXP farming material for air units
-Attacker, by +2 (result of 6) - Attackers are hard to balance without butchering their identity, 
though at least the defender getting a lot of EXP off of this beast would stagger attrition, 
and the 600 EXP bounty for zapping this thing out of existence would also wreck bad management
-Transport Helicopter, by +2 (result of 3) - lesser reward for catching this mobile trickster than 
what the APC would provide? Yeah, no, I don't think so.

Considered but not done:
-Light Tank (further increase) - FTA pest gets on my radar immediately. Unfortunately, an increase 
would have it at the same PUT multiplier as the Medium Tank, so this is a no-go.
-Anti-Air Missile Launcher (no increase) - they say that only drunks and idiots get hit by Missile 
Trucks. But honestly, the AAML would still be hard to catch through a cluster, and I'm planning 
to give both it ahd the Anti-Air Artillery an extra space of range, which would benefit both, 
though with the AAML still benefiting more actively.
-Fighter (no increase) - worth consideration in the final product. However, aesthetic makes this guy 
the intended king of the skies, so I'd have to be watchful with reducing the bounty.
-Lander (no increase) - to be sure, the Lander can't attack and can't really evade attacks, so 
it's a worry to have this with a higher PUT multiplier than the Transport Helicopter. Still, I do 
need to involve consistency with the navy, and there's supposed to be high bounties with them. 
When the Transport Fix Patch especially makes sure units don't get butchered, the Lander gains 
some more value.to let it function regardless

----------------------------------------------------------------------------------------------------

Movement Costs Patch

Changes are as follows:
-Foot Movement Type Beach Cost reduced 2 -> 1
-Treads Movement Type Rails Cost reduced 2 -> 1
-Tires newly able to move onto Forests at 3 Movement Cost
-Tires Movement Type Beach and Rails Costs reduced 4 -> 2

Simple changes to be more in line with the Advance Wars games in general. To be sure, in AW1 to 
AWDS, the Beach terrain didn't slow down Tire units. It did, however, do so in Days of Ruin. And 
I'm for keeping in line with the Tire Movement Type weaknesses.

----------------------------------------------------------------------------------------------------

Stats Balancing Patch

Quick fix: Damage now mechanically caps at 240%, with ASM rearranged to make sure the attacker is 
the one whose potential damage capping happens after the Level defense boost is applied. (Mostly 
for preventing overflow damage. Damage calculation order of operations is updated to make sure the 
attacker would already one-shot with the damage cap triggering.)


(Note that unless specifically stated otherwise, damage values changes against the Artillery are 
also applied to the Anti-Air Artillery, and likewise ones against the Rocket Launcher are to the 
Anti-Air Missile Launcher.)

                                            Infantry
There's not too much changes to the Infantry within their own stats, just a whole host of damage 
taken increases to discourage spamming them. The few changes Infantry get within their own stats 
are damage increases, though minor ones.

-Weapon damage value changes:
--Recon: 6 -> 12
--Train Gun: 1 -> 4
--Transport Helicopter: 20 -> 25

                                             Bazooka
Bazooka soldiers (Mechs) still keep the same Movement Type to their detriment here in SFW 
beacause programming limitations are fun. (Technically, I could get something going by getting 
rid of the Famicom Wars terrain cover involvement leftovers, but with more effort than I'm 
willing to put in.) Even so, I'm at least able to give them a better anti-armor role so that 
they can actually pack a better punch against vehicles than the Light Tank does/will. As a 
general note, MG changes against vehicles mostly only matter if the primary weapon is depleted, 
though there is potential gameplay involvement when that happens which would be...not often, 
really.

-Primary weapon damage value changes:
--Light Tank: 55 -> 65
--Recon: 55 -> 90
--APC: 55 -> 75
--Supply Truck: 75 -> 80
--Artillery: 65 -> 105
--Rocket Launcher: 75 -> 125
--Train Gun: 25 -> 30
--Anti-Air Tank: 45 -> 75
-Secondary weapon damage value changes:
--Medium Tank: 4 -> 5
--Light Tank: 6 -> 8
--Recon: 9 -> 45
--APC: 10 -> 20
--Supply Truck: 35 -> 40
--Artillery: 32 -> 35
--Rocket Launcher: 35 -> 45
--Train Gun: 2 -> 6
--Anti-Air Tank: 6 -> 15
--Battle Helicopter: 9 -> 10
--Transport Helicopter: 25 -> 30

                                            Heavy Tank
This is a 4 Movement Power that is direct fire. AW1 toned it up to 5 Movement Power and still 
price decreased it. I'm agreeing with the price decrease. The Heavy Tank does get a modest 
durability nerf with only one matchup where it takes less (the Bomber, see below), but it hits 
harder by a good amount against enough units, so a full health Heavy Tank is something that 
really would warrant wariness now.

-Price reduced 18000G -> 16000G
-Primary weapon damage value changes:
--Light Tank: 95 -> 85
--Recon: 99 -> 120
--APC: 99 -> 100
--Supply Truck: 99 -> 120
--Artillery: 99 -> 125
--Rocket Launcher: 99 -> 150
--Anti-Air Tank: 90 -> 105
--Battleship: 10 -> 40
--Cruiser: 25 -> 70
--Lander: 35 -> 85
-Secondary weapon damage value changes:
--Infantry: 95 -> 125
--Bazooka: 90 -> 115
--Medium Tank: 6 -> 7
--Light Tank: 8 -> 15
--Recon: 12 -> 90
--APC: 15 -> 35
--Supply Truck: 35 -> 95
--Artillery: 34 -> 55
--Rocket Launcher: 35 -> 70
--Train Gun: 3 -> 12
--Anti-Air Tank: 7 -> 40
--Battle Helicopter: 12 -> 20
--Transport Helicopter: 30 -> 60

                                           Medium Tank
The Medium Tank's damage output improvement isn't as big as the Heavy Tank's, relying on already 
plentiful involvement of durability reduction of units that shouldn't be sponging so much abuse,
and it also gets slightly more durability reduction of its own because it actually has mobility, 
but it should still prove to be good enough at its job to disrupt spam setups.

-Primary weapon damage value changes:
--Heavy Tank: 25 -> 30
--Light Tank: 80 -> 75
--Recon: 90 -> 105
--APC: 90 -> 85
--New Model Tank: 20 -> 25
--Supply Truck: 95 -> 105
--Artillery: 90 -> 110
--Rocket Launcher: 95 -> 130
--Anti-Air Tank: 70 -> 90
--Battleship: 5 -> 20
--Cruiser: 10 -> 50
--Lander: 15 -> 75
-Secondary weapon damage value changes:
--Infantry: 85 -> 105
--Bazooka: 80 -> 95
--Medium Tank: 5 -> 6
--Light Tank: 7 -> 12
--Recon: 11 -> 75
--APC: 13 -> 30
--Supply Truck: 32 -> 80
--Artillery: 31 -> 45
--Rocket Launcher: 32 -> 60
--Train Gun: 3 -> 9
--Anti-Air Tank: 6 -> 30
--Battle Helicopter: 11 -> 16
--Transport Helicopter: 28 -> 50

                                            Light Tank
This is now the designated weakest explosive attack unit. The Light Tank is also given a price 
increase, though not to the 7000G mark that is used in the Advance Wars series. With the 
exceptions of the Heavy Tank, New Model Tank, and Train Gun, the Light Tank takes significantly 
more damage from explosive attacks, so it would be easier to equalize. Dealing 80% to Infantry 
rather than 75% will not change this.

-Price increased 6000G -> 6500G
-Primary weapon damage value changes:
--Heavy Tank: 5 -> 15
--Medium Tank: 25 -> 30
--Recon: 70 -> 85
--APC: 75 -> 65
--New Model Tank: 5 -> 12
--Supply Truck: 90 -> 70
--Artillery: 70 -> 85
--Rocket Launcher: 85 -> 100
--Train Gun: 35 -> 25
--Anti-Air Tank remains at 65
--Battleship: 1 -> 10
--Cruiser: 5 -> 25
--Lander: 10 -> 55
-Secondary weapon damage value changes:
--Infantry: 75 -> 80
--Bazooka: 70 -> 70
--Medium Tank: 4 -> 5
--Light Tank: 6 -> 10
--Recon: 9 -> 55
--APC: 13 -> 25
--Supply Truck: 30 -> 60
--Artillery: 31 -> 40
--Rocket Launcher: 32 -> 50
--Train Gun: 3 -> 7
--Anti-Air Tank: 6 -> 25
--Battle Helicopter: 11 -> 14
--Transport Helicopter: 28 -> 45

                                              Recon
Machine Gun damage against Infantry is more along the lines of the Advance Wars games. The APC 
actually should prove to stop this from being too much of an FTA pest.

-Weapon damage value changes:
--Infantry: 70 -> 75
--Medium Tank: Remains at 4 (5 considered but not done)
--Light Tank: 6 -> 8
--Recon: 9 -> 35
--APC: 10 -> 12
--Supply Truck: 28 -> 40
--Artillery: 27 -> 45
--Rocket Launcher: 28 -> 55
--Train Gun: 2 -> 7
--Anti-Air Tank: 4 -> 10
--Battle Helicopter: 10 -> 14
--Transport Helicopter: 26 -> 35

                                    Armored Personnel Carrier
It's funny how this turns out to have the same MG as the Recon. This is maintained other than 
giving the APC some (VERY slight in practicality) anti-air power.

-Weapon damage value changes:
--Same as Recon for all land units
--Battle Helicopter: 9 -> 18
--Transport Helicopter: 25 -> 55

                                         New Model Tank
Light Tank damage is trimmed to involve the 1HKO against it on Roads being a gamble for a 
clear-cut value unit, and the NMT is a bit more of a Glass Cannon now as well due to its whopping 
6 Movement Power making it so maneuverable. Ammo is also trimmed to reduce its momentum a bit.

-Ammo reduced 12 -> 10
-Primary weapon damage value changes:
--Light Tank: 99 -> 95
--Recon: 99 -> 125
--APC: 99 -> 105
--Supply Truck: 99 -> 125
--Artillery: 99 -> 135
--Rocket Launcher: 99 -> 160
--Anti-Air Tank: 95 -> 115
--Battleship: 10 -> 45
--Cruiser: 30 -> 75
--Lander: 45 -> 90
-Secondary weapon damage value changes same as Heavy Tank

                                            Artillery
The only reason Artillery spam gets anywhere in the Advance Wars games is because they're just 
not volatile enough to allow for punishing an aggressive cluster, but that ends up being changed 
up in general. As a result, it's safe to give them their AW series price tag and Movement Power, 
as well as better damage values, although still minimal against the Heavy Tank.

-Price reduced 7000G -> 6000G
-Movement Power improved 4 -> 5
-Ammo reduced 10 -> 6
-Weapon damage value changes:
--Heavy Tank: 25 -> 30
--Medium Tank: 40 -> 50
--Light Tank: 55 -> 70
--Recon: 65 -> 80
--APC: 85 -> 80
--New Model Tank: 30 -> 40
--Supply Truck: 95 -> 80
--Artillery: 65 -> 80
--Rocket Launcher: 70 -> 90
--Train Gun: 35 -> 60
--Anti-Air Tank: 45 -> 85
--Battleship: 30 -> 45
--Cruiser: 40 -> 75
--Lander: 55 -> 90

                                         Rocket Launcher
Damage against the Heavy Tank is kept minimal because a 5 range unit is still capable of more 
shenanigans than welcome. Otherwise, the damage changes are still (for the most part) a good 
amount with the damage against foot soldiers being improved by quite a bit in a shout-out to the 
Game Boy Wars 3 Rocket Launcher being an anti-Lite Land indirect instead of a tech indirect.

-Movement Power improved 4 -> 5
-Ammo reduced 6 -> 5
-Weapon damage value changes:
--Infantry: 95 -> 125
--Bazooka: 90 -> 115
--Heavy Tank: 30 -> 35
--Medium Tank: 50 -> 60
--Light Tank: 65 -> 80
--Recon: 70 -> 125
--APC: 90 -> 90
--New Model Tank: 35 -> 45
--Supply Truck: 95 -> 115
--Artillery: 70 -> 85
--Rocket Launcher: 75 -> 95
--Train Gun: 40 -> 65
--Anti-Air Tank: 55 -> 90
--Battleship: 35 -> 50
--Cruiser: 45 -> 80
--Lander: 60 -> 95

                                            Train Gun
Minimum Range increase is due to this thing playing God in general on maps where it's available. 
It does get added offense power and not much durability reduction, though the Battleship at least 
will newly wreck it if it moves into that thing's range. It's advised to be playing with the 
Movement Costs Patch anyway, with having Rails not crippling unit mobility being one more reason 
to do so.

-Primary weapon Minimum Range increased 2 -> 3
-Primary weapon damage value changes:
--Infantry: 99 -> 135
--Bazooka: 99 -> 125
--Heavy Tank: 50 -> 50
--Medium Tank: 70 -> 80
--Light Tank: 90 -> 90
--Recon: 95 -> 125
--APC: 95 -> 100
--New Model Tank: 50 -> 60
--Supply Truck: 95 -> 125
--Artillery: 95 -> 105
--Rocket Launcher: 99 -> 115
--Train Gun: 60 -> 75
--Anti-Air Tank: 80 -> 105
--Battleship: 55 -> 60
--Cruiser: 75 -> 100
--Lander: 90 -> 125
-Secondary weapon damage value changes:
--Infantry: 65 -> 105
--Bazooka: 60 -> 95
--Medium Tank: 6 -> 7
--Light Tank: 8 -> 13
--Recon: 12 -> 85
--APC: 15 -> 32
--Supply Truck: 55 -> 90
--Artillery: 35 -> 50
--Rocket Launcher: 45 -> 65
--Train Gun: 4 -> 10
--Anti-Air Tank: 8 -> 35
--Battle Helicopter: 15 -> 18
--Transport Helicopter: 35 -> 55

                                       Anti-Air Artillery
They say you can't polish a turd, but you could honestly say that about SFW in its dated design, 
and really, in Anti-Air Artillery's case, there's no harm in trying. While it does get similar 
durability reduction aside from resiting air unit attacks a bit, it does newly cost less, it can 
move faster than Artillery now, it hits air units harder including a 1HKO on the Attacker, and 
2~4 Range is, while still likely to be outmaneuvered, something that should prove to be a tad 
more passable for discount anti-air and can cover a possible bait target on all flanks.

-Price reduced 6500G -> 4000G
-Movement Power improved 4 -> 6
-Maximum Range increased 3 -> 4
-Weapon damage value changes:
--Fighter: 55 -> 75
--Bomber: 75 -> 90
--Attacker: 65 -> 110
--Battle Helicopter: 90 -> 100
--Transport Helicopter: 95 -> 105

                                          Anti-Air Tank
Ammo is reduced to 7, but this is justified by the attack power against foot units now not only 
working but actually 1HKOing them through 2 Star terrain and Infantry even having a chance of 
being 1HKOed through Cities' 3 Stars, becoming foolproof on the Kinetic Damage Calculations Patch; 
in addition to actual attack power against air units, again including a 1HKO against the Attacker.

-Ammo reduced 14 -> 7
-Weapon damage value changes:
--Infantry: 95 -> 135
--Bazooka: 90 -> 125
--Heavy Tank: 0 -> 1
--Medium Tank: 10 -> 8
--Light Tank: 25 -> 20
--Recon: 50 -> 100
--APC: 65 -> 40
--New Model Tank: 0 -> 1
--Supply Truck: 80 -> 100
--Train Gun: 5 -> 15
--Fighter: 25 -> 70
--Bomber: 35 -> 85
--Attacker: 25 -> 100
--Battle Helicopter: 85 -> 105
--Transport Helicopter: 95 -> 110

                                    Anti-Air Missile Launcher
People have argued this to be THE worst unit in the Advance Wars series. While GBW3's Tanker in 
base game exists, the AAML does have convincing arguments about involving overreliance on planes 
being lock-and-key units in the first place. Add in its competition, and that's good enough reason 
to give this thing the works. Lower price by 3K, improved Movement Power, better damage that 
includes more consistent Attacker 1HKOing, and 3~6 Range instead of 3~5 won't necessarily turn 
this lead into gold, but at least it may be able to hit more than drunks and idiots.

-Price reduced 13000G -> 10000G
-Movement Power improved 4 -> 6
-Maximum Range increased 5 -> 6
-Weapon damage value changes:
--Fighter: 70 -> 85
--Bomber: 90 -> 100
--Attacker: 80 -> 125
--Battle Helicopter: 95 -> 115
--Transport Helicopter: 95 -> 120

                                             Fighter
There was only so much that could be done with the Fighter. At least it still has the benefit of 
being a mobile response to air units, and actually a sturdy enough one at that. The comparison 
to the Attacker was particularly important to consider.

-Primary weapon damage value changes:
--Bomber: 95 -> 75
--Attacker: 80 -> 95
--Battle Helicopter: 95 -> 105
--Transport Helicopter: 95 -> 120
-Secondary weapon damage value changes:
--Fighter: 15 -> 40
--Bomber: 45 -> 55
--Attacker: 35 -> 70
--Battle Helicopter: 65 -> 80
--Transport Helicopter: 75 -> 90

                                             Bomber
90% against all land units and 30% against all sea units was incredibly devoid of depth in the 
battle performance. This was obviously changed up. There's plenty of 1HKO potential across the 
board against land units now with varying potential to get past terrain cover and minor amounts of 
missing HP. The Anti-Air Tank newly resists the Bomber a bit, so that's worth watching out for. 
Bote damage is also heavily improved, though the Cruiser also resists it, so that's another alarm 
unit to be wary of.

-Weapon damage value changes from 90 VS land and 30 VS sea:
--Infantry: 125
--Bazooka: 115
--Heavy Tank: 85
--Medium Tank: 105
--Light Tank: 120
--Recon: 140
--APC: 125
--New Model Tank: 95
--Supply Truck: 130
--Artillery: 160
--Rocket Launcher: 180
--Train Gun: 115
--Anti-Air Artillery: 120
--Anti-Air Tank: 75
--Anti-Air Missile Launcher: 135
--Battleship: 75
--Cruiser: 55
--Lander: 95

                                            Attacker
Quite a bit was done with the Attacker to have it live up to its name while being able to 
justify its price decrease from 26K by making it more of a Glass Cannon. Against land and sea, 
it's placed at around a halfway mark between the Bomber and the Battle Helicopter in terms of 
the new attack power, which notably results in the only nerfs to the damage output against both, 
against the Anti-Air Tank and Cruiser, both of which will be very happy to bring up the 
Attacker's introduced immense volatility in their counterattacks. The clear surface-to-air units 
ALL newly 1HKO the Attacker by default at minimum, so the Attacker would need to be so much more 
considerate of them. Against air units, the Fighter is a significantly less fool-proof answer, 
but no less capable of what can be called "anti-meta" since the Attacker's volatility sees to the 
matchup still being less favorable for the Attacker than desired to call out the Attacker also 
still being free damage VS the Bomber and the helicopters. And naturally, to punctuate this, the 
Attacker mirror is set to 75%, higher than the Battle Helicopter's 65% in the Advance Wars series. 
Also for good measure, the Attacker's general-purpose missile Ammo is reduced to 4, and its MG has 
its buffing be modest, limiting its contribution VS the foot soldier spam, but that's what your 
other units are for.

In short? The Attacker should now prove to be for burst attack setup over simply breaking 
everything.

-Price reduced 26000G -> 22000G
-Ammo reduced 6 -> 4
-Primary weapon damage value changes:
--Heavy Tank: 45 -> 60
--Medium Tank: 55 -> 80
--Light Tank: 65 -> 100
--Recon: 70 -> 115
--APC: 75 -> 105
--New Model Tank: 45 -> 65
--Supply Truck: 75 -> 105
--Artillery: 75 -> 125
--Rocket Launcher: 75 -> 140
--Train Gun: 60 -> 80
--Anti-Air Artillery: 75 -> 90
--Anti-Air Tank 60 -> 50
--Anti-Air Missile Launcher: 75 -> 105
--Fighter: 35 -> 45
--Bomber: 70 -> 60
--Attacker: 55 -> 75
--Battle Helicopter: 75 -> 85
--Transport Helicopter: 75 -> 100
--Battleship: Remains at 55
--Cruiser: 65 -> 40
--Lander: 75 -> 70
-Secondary weapon damage value changes:
--Infantry: 70 -> 80
--Bazooka: 70 -> 70
--Medium Tank: 3 -> 5
--Light Tank: 5 -> 10
--Recon: 8 -> 55
--APC: 10 -> 25
--Supply Truck: 25 -> 50
--Artillery: 15 -> 40
--Rocket Launcher: 25 -> 50
--Train Gun: 1 -> 7
--Anti-Air Artillery: 15 -> 30
--Anti-Air Tank: 5 -> 2
--Anti-Air Missile Launcher: 25 -> 40
--Fighter: 10 -> 30
--Bomber: 30 -> 35
--Attacker: 20 -> 45
--Battle Helicopter: 55 -> 50
--Transport Helicopter: 65 -> 60

                                        Battle Helicopter
As little of a fan as I am in Days of Ruin's elitism feeding that gave prominence to a guy who 
mocked a lust-induced murder victim and never gave a genuine apology about as much while being 
allowed to spew racist rhetoric, I will at least say that the Battle Helicopter's base damage 
increase against the Light Tank is a valid point, the issue being that compared to the prior AWs, 
the base damage against the Mech was reduced and the base damage against Artillery remained the 
same. The Battle Helicopter now newly 1HKOs foot units by default, and while it still won't 1HKO 
Artillery, the attack boost needed for doing so is smaller and the unit itself can still carry 
out good poke damage with an air unit, and the mirror has the 65% base that it has in the regular 
AWs. By the way, effectiveness against the Cruiser is heavily reduced on both ends of the matchup; 
there's no reason this should be cost-effective against the navy's take on the Anti-Air Tank.

-Price increased 8500G -> 9000G
-Primary weapon damage value changes:
--Heavy Tank: 10 -> 30
--Medium Tank: 25 -> 45
--Light Tank: 45 -> 70
--Recon: 55 -> 85
--APC: 60 -> 75
--New Model Tank: 0 -> 30
--Supply Truck: 65 -> 80
--Artillery: 60 -> 85
--Rocket Launcher: 65 -> 100
--Train Gun: 30 -> 35
--Anti-Air Artillery: 60 -> 65
--Anti-Air Tank: 30 -> 20
--Anti-Air Missile Launcher: 65 -> 75
--Battleship: 25 -> 35
--Cruiser: 40 -> 20
--Lander: 65 -> 45
-Secondary weapon damage value changes:
--Infantry: 75 -> 115
--Bazooka: 75 -> 105
--Medium Tank: 4 -> 7
--Light Tank: 6 -> 15
--Recon: 9 -> 80
--APC: 10 -> 35
--Supply Truck: 40 -> 75
--Artillery: 25 -> 55
--Rocket Launcher: 35 -> 70
--Train Gun: 3 -> 12
--Anti-Air Artillery: 25 -> 40
--Anti-Air Tank: 6 -> 4
--Anti-Air Missile Launcher: 35 -> 55
--Battle Helicopter: 45 -> 65
--Transport Helicopter: 60 -> 85

                                      Transport Helicopter
One direct change to the Transport Helicopter in its own stats and it's just a price increase 
because of the direct competition with the APC. It also has durability decreases across the board 
other than the Attacker's MG and Battleship's cannon dealing less to it for what that entails.

-Price increased 5500G -> 6000G

                                           Battleship
You might notice already that there's a price drop. That's to make the navy in general less 
expensive, and I'm going with the Days of Ruin price for the Battleship as a starting point. 
Since this isn't the Days of Ruin Battleship with the move-and-fire capability, damage values 
are improved across the board other than against the air units except for, what else, the 
Attacker. Sieges should now prove to be better. MG is improved, aside from performance reduction 
against the Battle Helicopter, though expect it to still be a meme addition.

-Price reduced 35000G -> 25000G
-Primary weapon damage value changes:
--Infantry: 75 -> 110
--Bazooka: 70 -> 105
--Heavy Tank: 35 -> 55
--Medium Tank: 50 -> 70
--Light Tank: 65 -> 85
--Recon: 65 -> 120
--APC: 70 -> 100
--New Model Tank: 35 -> 60
--Supply Truck: 75 -> 120
--Artillery: 70 -> 85
--Rocket Launcher: 75 -> 95
--Train Gun: 35 -> 65
--Anti-Air Tank: 55 -> 105
--Fighter: 45 -> 35
--Bomber: 65 -> 45
--Attacker: Remains at 55
--Battle Helicopter: 75 -> 65
--Transport Helicopter: 75 -> 70
--Cruiser: 75 -> 90
--Lander: 95 -> 110
-Secondary weapon damage value changes:
--Infantry: 25 -> 90
--Bazooka: 20 -> 80
--Medium Tank: 3 -> 4
--Light Tank: 5 -> 6
--Recon: 8 -> 25
--APC: 10 -> 15
--Supply Truck: 25 -> 30
--Artillery: 15 -> 45
--Rocket Launcher: 25 -> 55
--Train Gun: 1 -> 5
--Anti-Air Tank: 5 -> 8
--Battle Helicopter: 20 -> 8
--Transport Helicopter: 25 -> 30

                                             Cruiser
Once again, the Cruiser gets its Days of Ruin price. Not only that, it can actually attack botes 
as whole, but with caveats, namely the mirror match being 35%, the damage against Battleships 
being 12%, and perhaps most importantly, Ammo being reduced to 3, which creates luck reliance with 
cost-effective damage against Battleships before having to restock. This is to make the Cruiser 
more of a bodyguard unit. Rest easy that the effectiveness against Subs remains high, and the MG 
still exists. The MG isn't good in base game, but that too is changed, because now, it's matching 
the Anti-Air Tank's power, without the Ammo limitation to force a restock when keeping the skies 
controlled with flak or getting rid of coastline foot soldiers. Now granted, it's still a direct 
fire bote, so this does only so much about the land-sea interaction, but reducing clutter can 
help with a D-Day operation a bit.

-Price reduced 22000G -> 16000G
-Ammo reduced 10 -> 3
-Primary weapon now damages all bote units with the following damage values:
--Battleship: 12
--Cruiser: 35
--Lander: 45
--Submarine: Buffed 95 -> 105
-Secondary weapon now deals damage to land and air units with the same damage values as the 
Anti-Air Tank's weapon; results in the following 2 buffs to preexisting damage:
--Battle Helicopter: 45 -> 105
--Transport Helicopter: 75 -> 110

                                              Lander
The Lander's increased fragility against explosive attacks is something to consider, though even 
without that, it's a navy staple, and it needs to involve vehicles to not be outclassed by the 
Transport Helicopter. Obviously, the price being reduced to 8K is to stabilize the inevitable 
costs in building the wanted landing force. Movement Power is also improved because really, sea 
maps are still going to be stuck with pacing issues, so some style is going to be needed.

-Price reduced 16500G -> 8000G
-Movement Power improved 5 -> 6

                                            Submarine
Price reduction to below what Days of Ruin itself has with the Sub is because of how the Cruiser 
is likely to be the buff dog to the base SFW Cruiser's crying dog and the Sub can be undermined 
by as much. Movement Power is improved to 6 to let the Sub actually freaking move around to make 
enemies say "you sank my battleship!" even in the presense of the Neo Cruiser. And speaking of, 
the Cruiser matchup is now a bit less disjointed, especially keeping in mind that Cruisers can 
more quickly run out of Ammo to defend themselves against Subs with.

-Price reduced 24000G -> 18000G
-Movement Power improved 4 -> 6
-Weapon damage VS Cruiser reduced 35 -> 25

----------------------------------------------------------------------------------------------------

Contact:
*Discord: MasterKnightDH
*YouTube: https://www.youtube.com/@MasterKnightDH

----------------------------------------------------------------------------------------------------

Credits

-schil227 for his inspiration with his patches for Famicom Wars, found here:
https://github.com/schil227/FamicomWarsFirstStrike
https://github.com/schil227/AdvanceFamicomWars
-The owner of Game Boy Wars Network for information provided here:
http://gbwn.main.jp/
-MarioMastar for being a long time friend in general
-Intelligent Systems for making Super Famicom Wars, of course
-The Advance Wars communities for providing general support, instead of claiming to have been 
trying to get rid of the troll for years despite evidence to the contrary and also not even 
bothering to link to Mangs' actions when calling him out while drowning out my efforts to call out 
the cobra effect by subjecting me to some cheap slander campaign and shutting out things like 
Nyvelion's unfairly deleted post about abuse by a Yandere
-Vanilla TV Tropes and Tropers' Hub for being all nice and pleasant non-snobbish people who don't 
ban people for grammar errors and prove generally exclusionary and unwilling to engage in 
respectable discussion while claiming to be democratic